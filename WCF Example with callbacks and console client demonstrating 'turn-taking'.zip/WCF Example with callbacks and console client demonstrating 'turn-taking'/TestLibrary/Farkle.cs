﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.ServiceModel;
using System.Threading;

namespace FarkleLibrary
{
    public interface ICallback
    {
        [OperationContract(IsOneWay = true)]
        void Update(int[] scores, int nextClient, bool gameOver);

        [OperationContract(IsOneWay = true)]
        void UpdateDiceRoll(string roll);
    }

    [ServiceContract(CallbackContract = typeof(ICallback))]
    public interface IFarkle
    {
        [OperationContract]
        int JoinGame();
        [OperationContract(IsOneWay = true)]
        void LeaveGame();

        
        [OperationContract(IsOneWay = true)]
        void RollDice();

        [OperationContract(IsOneWay = true)]
        void DisplayDice();
    }

    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single)]
    public class Farkle : IFarkle
    {
        private int[] scores = new int[9];                                              // Keeps track of the game count for this counting "game"
        //const int MAX_COUNT = 10;                                       // Game will be over when the count reaches this limit
        private readonly Dictionary<int, ICallback> callbacks = null;   // Stores id and callback for each client
        private int nextClientId;                                       // Unique Id to be assigned of next client that "Joins"
        private int clientIndex;                                        // Index of client that "counts" next
        private bool gameOver = false;
        private string roll;

        Dice[] dices = new Dice[6];

        // "Game over" flag

        public Farkle()
        {
            nextClientId = 1;
            clientIndex = 0;
            callbacks = new Dictionary<int, ICallback>();
            for (int i = 0; i < 6; i++)
            {
                dices[i] = new Dice();
            }
        }
        public int JoinGame()
        {
            ICallback callback = OperationContext.Current.GetCallbackChannel<ICallback>();
            if (callbacks.ContainsValue(callback))
            {
                int i = callbacks.Values.ToList().IndexOf(callback);
                return callbacks.Keys.ElementAt(i);
            }

            //maximum player # is 8
            if (clientIndex < 8)
            {
                callbacks.Add(nextClientId, callback);
                return nextClientId++;
            }
            //have to be implemented
            else return -1;
        }

        public void LeaveGame()
        {
            // Identify which client is calling this method
            ICallback cb = OperationContext.Current.GetCallbackChannel<ICallback>();

            if (callbacks.ContainsValue(cb))
            {
                // Identify which client is currently calling this method
                // - Get the index of the client within the callbacks collection
                int i = callbacks.Values.ToList().IndexOf(cb);
                // - Get the unique id of the client as stored in the collection
                int id = callbacks.ElementAt(i).Key;

                // Remove this client from receiving callbacks from the service
                callbacks.Remove(id);

                // Make sure the counting sequence isn't disrupted by removing this client
                if (i == clientIndex)
                    // This client was supposed to count next but is exiting the game
                    // Need to signal the next client to count instead 
                    UpdateAllClients();
                else if (clientIndex > i)
                    // This prevents a player from being "skipped over" in the turn-taking
                    // of this "game"
                    clientIndex--;
            }
        }

        public void RollDice() 
        {
            foreach (Dice d in dices)
            {
                if (!d.IsScored)
                    d.Roll();
                Console.WriteLine(d.Value);

                System.Threading.Thread.Sleep(10);
            }
        }

        public void DisplayDice()
        {
            roll = "";
            foreach (Dice d in dices)
            {
                if (!d.IsScored)
                {
                    roll += ("\nDice: " + d.Value);
                }
            }
            clientIndex = ++clientIndex % callbacks.Count;
            UpdateDiceRollAll();
        }

        private void UpdateAllClients()
        {
            foreach (ICallback cb in callbacks.Values)
                cb.Update(scores, callbacks.Keys.ElementAt(clientIndex), gameOver);
        }
        private void UpdateDiceRollAll() 
        {
            foreach (ICallback cb in callbacks.Values)
                cb.UpdateDiceRoll(roll);
            UpdateAllClients(); //Remove later
        }
    }

    public class Dice
    {
        public bool IsScored { get; set; }

        public int Value { get; set; }
        public Dice()
        {
            IsScored = false;
        }

        public void Roll()
        {
            var random = new Random();
            Value = random.Next(1, 7);
        }

        public void SetAside()
        {
            IsScored = true;
        }

        public void SetPlayable()
        {
            IsScored = false;
        }


    }
}