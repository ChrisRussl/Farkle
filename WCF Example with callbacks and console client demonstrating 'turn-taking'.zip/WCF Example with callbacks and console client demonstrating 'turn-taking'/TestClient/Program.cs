﻿/*
 * Program:     TestClient.exe
 * Module:      Program.cs
 * Author:      T. Haworth
 * Date:        March 14, 2023
 * Description: A console client for the WCF Counting service.  
 *              
 *              The purpose of this example is to demonstrate the following features:
 *              1.  The use of an object of type System.Threading.EventWaitHandle to temporarily
 *                  pause each instance of the client until it receives a signal that it's turn 
 *                  has come to play the game.
 *              2.  The use of the SetConsoleCtrlHandler() function to register an event handler 
 *                  that will trigger if the user tries to close the co[nsole window prematurely 
 *					(before the game is over) by clicking the close button at the top-right corner. 
 *					In this example the nadler function is used to allow the client to "unregister" 
 *					from the callbacks gracefully. Note that the code in the "unmanaged" region at 
 *					the bottom must be included if you wish to use this technique.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using FarkleLibrary; // Service contract and implementation
using System.ServiceModel;  // WCF types

using System.Threading;
using System.Runtime.InteropServices;   // Need this for DllImport()

namespace TestClient
{
    class Program
    {
        private class CBObject : ICallback
        {
            public void Update(int[] scores, int nextId, bool over)
            {
                activeClientId = nextId;
                gameOver = over;
                Console.WriteLine("Count is " + scores + ".");
                if (gameOver)
                {
                    // Release all clients so they can exit out
                    Console.WriteLine("*** The game is now over! Press any key to quit. ***");
                    waitHandle.Set();

                }
                else if (activeClientId == clientId)
                {
                    // Release this client's main thread to let this user "count"
                    Console.Write("It's your turn. Press enter to count.");
                    waitHandle.Set();
                }
            }

            public void UpdateDiceRoll(string roll)
            {
                Console.Write(roll);
            }
        }

        private static IFarkle farkle = null;   // service object reference
        private static int clientId, activeClientId = 0;
        private static CBObject cbObj = new CBObject();
        private static EventWaitHandle waitHandle = new EventWaitHandle(false, EventResetMode.ManualReset);
        private static bool gameOver = false;

        static void Main()
        {
            if (connect())
            {
                SetConsoleCtrlHandler(new HandlerRoutine(ConsoleCtrlCheck), true);

                do
                {
                    waitHandle.WaitOne();

                    if (gameOver)
                    {
                        Console.ReadKey();
                    }
                    else
                    {
                        Console.ReadLine();
                        farkle.RollDice();
                        farkle.DisplayDice();// This is where they will roll the d-ice
                        waitHandle.Reset();
                    }

                } while (!gameOver);

                farkle.LeaveGame();
            }
            else
            {
                Console.WriteLine("ERROR: Unable to connect to the service!");
            }
        }

        private static bool connect()
        {
            try
            {
                DuplexChannelFactory<IFarkle> channel = new DuplexChannelFactory<IFarkle>(cbObj, "TestEP");
                farkle = channel.CreateChannel();

                // Register for the callbacks (tells the Shoe object to include this instance of 
                // the client in future callback events (i.e. updates)
                clientId = farkle.JoinGame();

                Console.WriteLine("~ Welcome to the Counting Game! ~\n");

                if (clientId == 1)
                    // Only client connected so far so release this client to do the first "count"
                    // (necessary because a callback will only happen when a "count" is performed 
                    // and a callback is the mechanism used to release a client)
                    cbObj.Update(new int[9] , 1, false);

                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }
        }

        private static bool ConsoleCtrlCheck(CtrlTypes ctrlType)
        {
            switch (ctrlType)
            {
                case CtrlTypes.CTRL_C_EVENT:
                case CtrlTypes.CTRL_BREAK_EVENT:
                    break;
                case CtrlTypes.CTRL_CLOSE_EVENT:
                case CtrlTypes.CTRL_LOGOFF_EVENT:
                case CtrlTypes.CTRL_SHUTDOWN_EVENT:
                    farkle?.LeaveGame();
                    break;
            }
            return true;
        }

        #region unmanaged

        // Declare the SetConsoleCtrlHandler function
        // as external and receiving a delegate.

        [DllImport("Kernel32")]

        public static extern bool SetConsoleCtrlHandler(HandlerRoutine Handler, bool Add);

        // A delegate type to be used as the handler routine
        // for SetConsoleCtrlHandler.
        public delegate bool HandlerRoutine(CtrlTypes CtrlType);

        // An enumerated type for the control messages
        // sent to the handler routine.
        public enum CtrlTypes
        {
            CTRL_C_EVENT = 0,
            CTRL_BREAK_EVENT,
            CTRL_CLOSE_EVENT,
            CTRL_LOGOFF_EVENT = 5,
            CTRL_SHUTDOWN_EVENT
        }

        #endregion

    }
}
